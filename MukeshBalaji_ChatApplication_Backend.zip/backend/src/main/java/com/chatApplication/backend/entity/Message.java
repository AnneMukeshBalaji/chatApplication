package com.chatApplication.backend.entity;

import java.time.LocalDateTime;
import java.util.UUID;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "messages")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Message {
  @Id
  @GeneratedValue(strategy = GenerationType.UUID)
  @Column(name = "id", updatable = false)
  private UUID id;
  @Column(name = "content", nullable = false, columnDefinition = "TEXT")
  private String content;
  @ManyToOne
  @JoinColumn(name = "sender_id", nullable = false)
  private User sender;
  @ManyToOne
  @JoinColumn(name = "recipient_id", nullable = false)
  private User recipient;
  @CreationTimestamp
  @Column(name = "timeStamp", nullable = false)
  private LocalDateTime timeStamp;
  @Column(name = "status", nullable = false)
  @Enumerated(EnumType.STRING)
  private MessageStatus status;
}
